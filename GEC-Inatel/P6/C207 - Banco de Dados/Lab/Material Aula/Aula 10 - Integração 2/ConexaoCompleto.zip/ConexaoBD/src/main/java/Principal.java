import dao.InstrumentoDAO;
import model.Instrumento;

import java.util.ArrayList;

public class Principal {

    public static void main(String[] args) {
        InstrumentoDAO iDAO = new InstrumentoDAO();

        Instrumento i1 = new Instrumento();
        i1.nome = "Violino";
        i1.marca = "Stradivarius";
        i1.idade = 150;

        //inserir--------------------------
        /*if(iDAO.inserirInstrumento(i1)){
            System.out.println("Instrumento inserido");
        }
        else{
            System.out.println("Alguma coisa n rolou");
        }

        //alterar--------------------------
        i1.idade = 20;
        if(iDAO.atualizarInstrumento(1, i1)){
            System.out.println("Instrumento alterado");
        }
        else{
            System.out.println("Alguma coisa n rolou");
        }

        //deletar---------------------------
        if(iDAO.deletarInstrumento(3)){
            System.out.println("Instrumento deletado");
        }
        else{
            System.out.println("Alguma coisa n rolou");
        }*/

        ArrayList<Instrumento> orquestra = iDAO.buscarInstrumentosSemFiltro();

        System.out.println("-------------------------------");
        System.out.println("Arraylist na main -------------");
        for (int i=0; i<orquestra.size(); i++){
            System.out.println("---");
            System.out.println("Nome: " + orquestra.get(i).nome);
            System.out.println("Marca: " + orquestra.get(i).marca);
            System.out.println("Idade: " + orquestra.get(i).idade);
        }


        System.out.println("-------------------------------");
        System.out.println("Instrumento na main");
        Instrumento ins = iDAO.buscarInstrumentoPorId(4);
        System.out.println("Nome: " + ins.nome);
        System.out.println("Marca: " + ins.marca);
        System.out.println("Idade: " + ins.idade);

    }
}
