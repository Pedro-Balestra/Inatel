import jdk.swing.interop.SwingInterOpUtils;

import java.util.*;

public class Principal {
    public static void main(String[] args) {
        //COLEÇOES
        //arraylist
        //nao precisa definir o tamanho
        //nao precisa preocupar com not null
        //facilitadores pra ordenação, maior valor, menor, filtros
        //qualquer tipo de dado

        List lista = new ArrayList();
        lista.add(5);
        lista.add(true);
        lista.add("O gohan cortou as unhas");

        Planta p1 = new Planta();
        p1.nome = "Erva-doce";
        p1.preco = 2.5f;
        p1.uso = "Chá e salada";
        p1.tamanho = 20;

        lista.add(p1);

        System.out.println("Na posição 2 tem: " + lista.get(2));

        System.out.println("");
        System.out.println("--------------------");
        for(int i=0; i<lista.size(); i++){
            System.out.println(lista.get(i));
        }

        ArrayList<String> frutas = new ArrayList<String>();
        frutas.add("Uva verde sem semente");
        frutas.add("Maçã");
        frutas.add("Maracujá");
        frutas.add("Tomate");

        System.out.println("");
        System.out.println("--------------------");
        for(int i=0; i<frutas.size(); i++){
            System.out.println(frutas.get(i));
        }

        Collections.sort(frutas);
        System.out.println("");
        System.out.println("--------------------");
        System.out.println("Arraylist ordenado");
        for(int i=0; i<frutas.size(); i++){
            System.out.println(frutas.get(i));
        }

        Collections.reverse(frutas);
        System.out.println("");
        System.out.println("--------------------");
        System.out.println("Arraylist ordenado ao contrario");
        for(int i=0; i<frutas.size(); i++){
            System.out.println(frutas.get(i));
        }

        ArrayList<Integer> numeros = new ArrayList<>();
        numeros.add(3);
        numeros.add(7);
        numeros.add(39);

        System.out.println("Maior numero: " + Collections.max(numeros));
        System.out.println("Menor numero: " + Collections.min(numeros));


        Planta p2 = new Planta();
        p2.nome = "Babosa";
        p2.preco = 20;
        p2.tamanho = 50;
        p2.uso = "Tudo(hidratação, curar queimadura, fazer shampoo estranho e demais)";

        Planta p3 = new Planta();
        p3.nome = "Samambaia";
        p3.preco = 40;
        p3.tamanho = 200;
        p3.uso = "Plantar orquídea";

        Planta p4 = new Planta();
        p4.nome = "Laranjeira";
        p4.preco = 50;
        p4.tamanho = 120;
        p4.uso = "Dar laranja";


        ArrayList<Planta> plantas = new ArrayList<>();
        plantas.add(p1);
        plantas.add(p2);
        plantas.add(p3);
        plantas.add(p4);

        System.out.println("");
        System.out.println("--------------------");
        for(int i=0; i<plantas.size(); i++){
            System.out.println(plantas.get(i));
        }

        Collections.sort(plantas);
        System.out.println("");
        System.out.println("--------------------");
        System.out.println("Arraylist ordenado");
        for(int i=0; i<plantas.size(); i++){
            System.out.println(plantas.get(i));
        }


        //HASHSET - CONJUNTO
        //ORDENADO
        //NAO PERMITE REPETIÇÃO

        Set<Integer> primos = new HashSet<>();
        primos.add(7);
        primos.add(3);
        primos.add(11);
        primos.add(5);
        primos.add(2);
        primos.add(5);
        System.out.println(primos);

        Map<String, String> estados = new HashMap<>();
        estados.put("MG", "Minas Gerais");
        estados.put("SP", "São Paulo");
        System.out.println("Mg: " + estados.get("MG"));
        System.out.println(estados.keySet());
        System.out.println(estados.entrySet());

        plantas.remove(2);
        System.out.println("");
        System.out.println("--------------------");
        System.out.println("Arraylist ordenado");
        for(int i=0; i<plantas.size(); i++){
            System.out.println(plantas.get(i));
        }

        plantas.clear();
        if(plantas.isEmpty()){
            System.out.println("Ta vazio mano");
        }
    }
}
