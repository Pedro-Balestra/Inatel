package br.inatel.projeto.dao;

public class CasaDao {
}
