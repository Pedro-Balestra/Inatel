package br.inatel.projeto.model;

public class Casa {
    public String dono;
    public int numQuartos;
    public float aluguel;
}
