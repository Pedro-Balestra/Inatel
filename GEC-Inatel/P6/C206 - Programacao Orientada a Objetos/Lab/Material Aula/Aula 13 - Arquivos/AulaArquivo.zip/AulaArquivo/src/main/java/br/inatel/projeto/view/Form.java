package br.inatel.projeto.view;

public class Form {
}
