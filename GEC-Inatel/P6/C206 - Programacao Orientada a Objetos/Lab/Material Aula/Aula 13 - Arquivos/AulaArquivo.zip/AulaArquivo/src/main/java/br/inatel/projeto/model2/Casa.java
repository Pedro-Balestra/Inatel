package br.inatel.projeto.model2;

public class Casa {
    public String endereco;
}
