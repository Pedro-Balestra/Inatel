/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula6;

import aula6.teste.Conta;

/**
 *
 * @author Uttoni
 */
public class Aula6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Conta c1 = new Conta();
        c1.numConta = 1234;
        c1.nome = "Uttoni";
        c1.setCpf(123456789);
        c1.setSaldo(2000);
        
        System.out.println("Saldo: " + c1.getSaldo());
        System.out.println(c1.getCpf());
        c1.sacar(250);
        
        System.out.println("");
        Violao v1 = new Violao();
        v1.cor = "vermelho";
        v1.marca = "Yamaha";
        v1.tipoCorda = "Aço";
        v1.preco = 1500;
        
        System.out.println("Codigo v1: " + v1.codigo);
        
        Violao v2 = new Violao();
        v2.cor = "Preto";
        v2.marca = "Gianini";
        v2.tipoCorda = "Nylon";
        v2.preco = 500;
        System.out.println("Codigo v1: " + v1.codigo);
        System.out.println("Codigo v2: " + v2.codigo);
        
        System.out.println("Num cordas violão 1: " + v1.NUM_CORDAS);
        System.out.println("Num cordas violão 1: " + v2.NUM_CORDAS);
        
    }
    
}
