/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula6.teste;

/**
 *
 * @author Uttoni
 */
public class Conta {
    
    //Private - dentro da classe
    //public - de qualquer lugar
    //protected - como se fosse um private pra classe mae
    public int numConta;
    public String nome;
    long cpf;
    protected double saldo;

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public void sacar(double valor){
        if(podeSacar(valor)){
            saldo -= valor;
            System.out.println("Agora tenho " + saldo + " na conta");
        }else{
            System.out.println("Impossível sacar tal valor");
        }
    }
    
    private boolean podeSacar(double valor){
        if(valor>saldo){
            return false;
        }else{
            return true;
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
