public class Bolo {

    String massa;
    String recheio;
    boolean desconto;

    @Override
    public String toString() {
        return "Bolo{" +
                "massa='" + massa + '\'' +
                ", recheio='" + recheio + '\'' +
                ", desconto=" + desconto +
                '}';
    }
}
