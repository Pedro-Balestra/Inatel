public class Confeiteiro {

    //ATRIBUTOS ~ VARIAVEIS
    String nome;
    int idade;
    float salario;

    //AGREGAÇÃO
    Bolo boloA;

    //COMPOSIÇÃO
    Bolo boloC = new Bolo();

    //Construtor
    Confeiteiro(float salario){
        this.salario = salario;
    }
    Confeiteiro(){

    }


    //METODOS ~ FUNÇÕES
    void fazerBolo(){
        System.out.println("O(A) confeiteiro(a) " + nome + " está fazendo um bolo!");
    }
    void fazerBolo(int qtd){
        System.out.println("O(A) confeiteiro(a) " + nome + " está fazendo " + qtd + " bolo(s)!");
    }

    @Override
    public String toString() {
        return "Confeiteiro{" +
                "nome='" + nome + '\'' +
                ", idade=" + idade +
                ", salario=" + salario +
                ", boloA=" + boloA +
                ", boloC=" + boloC +
                '}';
    }

}
