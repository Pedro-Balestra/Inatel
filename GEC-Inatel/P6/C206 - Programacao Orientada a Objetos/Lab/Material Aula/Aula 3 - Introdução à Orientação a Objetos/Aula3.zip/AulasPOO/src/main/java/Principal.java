public class Principal {

    public static void main(String[] args) {
        Confeiteiro c1 = new Confeiteiro();
        c1.nome = "Breno";
        c1.idade = 35;
        c1.salario = 2000;

        System.out.println("Nome do Confeiteiro 1: " + c1.nome);

        Confeiteiro c2 = new Confeiteiro();
        c2.nome = "Joana";
        c2.idade = 27;
        c2.salario = 3547.65f;

        System.out.println("O confeiteiro " + c1.nome + " tem " + c1.idade + " anos");
        System.out.println("A confeiteira " + c2.nome + " tem " + c2.idade + " anos");
        c1.fazerBolo();
        c2.fazerBolo();
        c1.fazerBolo(3);
        c2.fazerBolo(5);


        //AGREGAÇÃO
        Bolo b1 = new Bolo();
        b1.massa = "Chocolate";
        b1.recheio = "Brigadeiro";
        b1.desconto = false;
        c1.boloA = b1;

        //COMPOSIÇÃO
        c2.boloC.massa = "Red Velvet";
        c2.boloC.recheio = "Ninho";
        c2.boloC.desconto = true;

        Confeiteiro c3 = new Confeiteiro(1500);
        c3.nome = "Lucas";
        c3.idade = 20;
        System.out.println("O salário do(a) " + c3.nome + " é " + c3.salario);

        Confeiteiro c4 = new Confeiteiro(1500);
        c4.nome = "Lucas";
        c4.idade = 20;

        System.out.println("");

        if(c3==c4){
            System.out.println("São iguais");
        }else{
            System.out.println("São diferentes");
        }

        System.out.println("C3: " + c3);
        System.out.println("C4: " + c4);

        System.out.println(c1.toString());
    }
}
