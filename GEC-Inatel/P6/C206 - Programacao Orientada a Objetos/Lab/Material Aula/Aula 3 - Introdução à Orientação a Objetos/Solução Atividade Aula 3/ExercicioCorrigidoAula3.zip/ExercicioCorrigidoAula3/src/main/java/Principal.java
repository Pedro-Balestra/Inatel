import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //CALCULADORA =======================================
        Calculadora calc = new Calculadora();
        float num1 = sc.nextFloat();
        float num2 = sc.nextFloat();

        calc.somar(num1, num2);
        calc.subtrair(num1, num2);
        calc.multiplicar(num1, num2);
        calc.dividir(num1, num2);

        //CONCESSIONARIA =====================================

        int potencia = sc.nextInt();
        sc.nextLine();
        String tipo = sc.nextLine();

        Motor m1 = new Motor(potencia, tipo);
        Carro c1 = new Carro();
        c1.cor = "Branco";
        c1.marca = "Fiat";
        c1.modelo = "Uno";
        c1.velMax = 200.5f;
        c1.velAtual = 97.3f;
        c1.motor = m1;

        Carro c2 = new Carro();
        c2.cor = "Preto";
        c2.marca = "Wolksvagen";
        c2.modelo = "Gol";
        c2.velMax = 180;
        c2.velAtual = 36.2f;
        c2.motor = m1;

        Carro c3 = new Carro();
        c3.cor = "Azul";
        c3.marca = "Chevrolet";
        c3.modelo = "Celta";
        c3.velMax = 190.79f;
        c3.velAtual = 83;
        c3.motor = m1;

        c1.ligar();
        c1.acelerar();
        c2.ligar();
        c2.acelerar();
        c3.ligar();
        c3.acelerar();
    }
}
