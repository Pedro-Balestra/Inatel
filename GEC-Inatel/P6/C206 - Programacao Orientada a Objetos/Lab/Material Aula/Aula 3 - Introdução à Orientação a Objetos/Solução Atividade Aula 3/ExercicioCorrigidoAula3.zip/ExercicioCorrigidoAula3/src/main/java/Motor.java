public class Motor {

    int potencia;
    String tipo;

    Motor(int potencia, String tipo){
        this.potencia = potencia;
        this.tipo = tipo;
    }
}
