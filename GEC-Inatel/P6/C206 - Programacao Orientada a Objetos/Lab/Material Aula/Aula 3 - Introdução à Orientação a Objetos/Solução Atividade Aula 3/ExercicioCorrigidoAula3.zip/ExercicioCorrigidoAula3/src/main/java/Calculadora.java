public class Calculadora {

    void somar(float n1, float n2){
        float soma = n1+n2;
        System.out.println("Soma: " + soma);
    }

    void subtrair(float n1, float n2){
        float sub = n1-n2;
        System.out.println("Subtração: " + sub);
    }

    void multiplicar(float n1, float n2){
        float mult = n1*n2;
        System.out.println("Multiplicação: " + mult);
    }

    void dividir(float n1, float n2){
        float div = n1/n2;
        if(n2 == 0){
            System.out.println("Divisão impossível");
        }else {
            System.out.println("Divisão: " + div);
        }
    }
}
