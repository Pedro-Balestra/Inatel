public class Carro {

    String cor;
    String marca;
    String modelo;
    float velMax;
    float velAtual;
    Motor motor;

    void ligar(){
        System.out.println("O " + modelo + " foi ligado!");
    }

    void acelerar(){
        System.out.println("O " + modelo + " carro acelerou!");
    }
}
