public interface Territorio {

    public void marcarTerritorio();
}
