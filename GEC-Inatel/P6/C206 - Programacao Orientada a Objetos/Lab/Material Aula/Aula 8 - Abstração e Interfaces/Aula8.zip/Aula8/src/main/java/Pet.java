public interface Pet {
    public abstract void fazerTruques();
}
