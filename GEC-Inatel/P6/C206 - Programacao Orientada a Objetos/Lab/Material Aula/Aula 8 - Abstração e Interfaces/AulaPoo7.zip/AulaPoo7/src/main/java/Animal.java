public abstract class Animal {
    public float peso;
    public int numPatas;

    public void mostraInfo(){
        System.out.println("Peso: " + peso);
        System.out.println("Num de Patas: " + numPatas);
    }

    public void comer(){
        System.out.println("Sou um animal, logo como...");
    }

    public abstract void hunt();
}
