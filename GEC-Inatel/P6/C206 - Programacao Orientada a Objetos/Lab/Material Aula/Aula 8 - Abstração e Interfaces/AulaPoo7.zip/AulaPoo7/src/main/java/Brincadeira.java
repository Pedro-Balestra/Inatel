public interface Brincadeira {
    public void brincar();
}
