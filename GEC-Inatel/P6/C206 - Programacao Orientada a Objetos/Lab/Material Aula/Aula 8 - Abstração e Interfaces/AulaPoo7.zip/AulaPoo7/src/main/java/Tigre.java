public class Tigre extends Animal{
    public int numListras;
    public boolean albino;

    @Override
    public void mostraInfo(){
        super.mostraInfo();
        System.out.println("NUm de Listras: " + numListras);
        System.out.println("É albino? " + albino);
    }

    @Override
    public void comer() {
        System.out.println("Só como carne, porque sou rico");
    }

    @Override
    public void hunt(){
        System.out.println("Caça animais de grande porte na floresta");
    }
}
