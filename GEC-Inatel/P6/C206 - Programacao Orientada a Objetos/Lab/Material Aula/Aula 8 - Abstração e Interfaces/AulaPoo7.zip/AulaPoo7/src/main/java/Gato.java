public class Gato extends Animal implements Pet, Brincadeira{
    public String nomeDono;

    @Override
    public void mostraInfo(){
        super.mostraInfo();
        System.out.println("Dono: " + nomeDono);
    }

    @Override
    public void fazerTruque() {
        System.out.println("Cai sempre de pé");
    }

    @Override
    public void brincar() {
        System.out.println("Tenta pegar pena de pavão");
    }

    @Override
    public void hunt(){
        System.out.println("Caça passarinhos e ratos");
    }
}
