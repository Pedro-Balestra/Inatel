public class Principal {
    public static void main(String[] args) {
        Tigre t1 = new Tigre();
        t1.numPatas = 4;
        t1.peso = 150;
        t1.numListras = 400;
        t1.albino = true;

        Gato g1 = new Gato();
        g1.numPatas = 4;
        g1.peso = 2.3f;
        g1.nomeDono = "Vinícius";

        Animal[] zoo = new Animal[10];
        zoo[0] = t1;
        zoo[1] = g1;

        for (int i=0; i<zoo.length; i++){
            if(zoo[i] != null){
                System.out.println("---------------------");
                zoo[i].mostraInfo();
                zoo[i].comer();
                zoo[i].hunt();
                if(zoo[i] instanceof Gato){
                    Gato gAux = (Gato) zoo[i];
                    gAux.fazerTruque();
                    gAux.brincar();
                }
            }
        }
    }
}
