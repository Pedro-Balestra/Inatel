public interface Pet {
    public void fazerTruque();
}
